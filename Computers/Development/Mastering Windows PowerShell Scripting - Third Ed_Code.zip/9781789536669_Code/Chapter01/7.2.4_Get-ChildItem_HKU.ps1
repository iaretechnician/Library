Get-ChildItem HKU:

