$tcpClient.Connected

# Expects:
#
# True