Restart-Service winrm
